#!/bin/sh
# Usage: ANDROID_SDK=/path/to/sdk ./build.sh   (needs platforms android-35 jar and build-tools)
set -e
SDK=${ANDROID_SDK:-/home/claude/sdk}
BT=${BUILD_TOOLS:-$SDK/android-16}
JAR=${ANDROID_JAR:-$SDK/android-35/android.jar}
VER_CODE=1
VER_NAME=1.0
rm -rf build && mkdir -p build/gen build/classes build/dex
"$BT/aapt2" compile --dir res -o build/res.zip
"$BT/aapt2" link -o build/base.apk -I "$JAR" --manifest AndroidManifest.xml --java build/gen \
  --min-sdk-version 21 --target-sdk-version 33 --version-code $VER_CODE --version-name $VER_NAME build/res.zip
javac -nowarn -source 8 -target 8 -cp "$JAR" -d build/classes $(find src build/gen -name '*.java') 2>&1 | grep -v '^warning\|^Note\|^[0-9]* warning' || true
"$BT/d8" --release --lib "$JAR" --min-api 21 --output build/dex $(find build/classes -name '*.class')
(cd build/dex && zip -q ../base.apk classes.dex)
"$BT/zipalign" -f 4 build/base.apk build/aligned.apk
[ -f release.jks ] || keytool -genkeypair -keystore release.jks -storepass tvtimesync -keypass tvtimesync \
  -alias tvtimesync -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=TV Time Sync" >/dev/null 2>&1
"$BT/apksigner" sign --ks release.jks --ks-pass pass:tvtimesync --key-pass pass:tvtimesync \
  --out build/TVTimeSync-$VER_NAME.apk build/aligned.apk
"$BT/apksigner" verify --verbose build/TVTimeSync-$VER_NAME.apk | head -4
ls -la build/*.apk
