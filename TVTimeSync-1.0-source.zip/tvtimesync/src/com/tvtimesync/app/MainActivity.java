package com.tvtimesync.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private TextView dateGregorian, dateJalali, zone, status, access, log;
    private ScrollView scroll;
    private Button btnSync, btnBoot, btnTest, btnZone, btnHelp;
    private volatile boolean busy;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            updateDates();
            ui.postDelayed(this, 1000);
        }
    };

    private final SyncEngine.Log engineLog = new SyncEngine.Log() {
        @Override
        public void line(String text) {
            appendLog(text);
        }

        @Override
        public void waitingForApproval() {
            appendLog(getString(R.string.adb_wait));
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dateGregorian = (TextView) findViewById(R.id.dateGregorian);
        dateJalali = (TextView) findViewById(R.id.dateJalali);
        zone = (TextView) findViewById(R.id.zone);
        status = (TextView) findViewById(R.id.status);
        access = (TextView) findViewById(R.id.access);
        log = (TextView) findViewById(R.id.log);
        scroll = (ScrollView) findViewById(R.id.scroll);
        btnSync = (Button) findViewById(R.id.btnSync);
        btnBoot = (Button) findViewById(R.id.btnBoot);
        btnTest = (Button) findViewById(R.id.btnTest);
        btnZone = (Button) findViewById(R.id.btnZone);
        btnHelp = (Button) findViewById(R.id.btnHelp);

        btnSync.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                runSync();
            }
        });
        btnBoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Prefs.setRunAtBoot(MainActivity.this, !Prefs.runAtBoot(MainActivity.this));
                updateBootButton();
            }
        });
        btnTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                runTest();
            }
        });
        btnZone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                runZone();
            }
        });
        btnHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                log.setText(getString(R.string.help_text));
                scroll.scrollTo(0, 0);
            }
        });
        updateBootButton();
    }

    @Override
    protected void onResume() {
        super.onResume();
        ui.post(tick);
        refreshAccess();
    }

    @Override
    protected void onPause() {
        super.onPause();
        ui.removeCallbacks(tick);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        worker.shutdownNow();
    }

    private void updateBootButton() {
        btnBoot.setText(Prefs.runAtBoot(this) ? R.string.btn_boot_on : R.string.btn_boot_off);
    }

    private void updateDates() {
        Calendar c = Calendar.getInstance();
        dateGregorian.setText(new SimpleDateFormat("EEEE, d MMMM yyyy", Locale.US).format(c.getTime()));
        int[] j = Jalali.fromGregorian(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
        dateJalali.setText(String.format(Locale.US, "%d %s %d   (%04d/%02d/%02d)",
                j[2], Jalali.MONTHS[j[1] - 1], j[0], j[0], j[1], j[2]));
        TimeZone tz = TimeZone.getDefault();
        int off = tz.getOffset(c.getTimeInMillis()) / 60000;
        zone.setText(String.format(Locale.US, "%s  (UTC%s%02d:%02d)", tz.getID(),
                off < 0 ? "-" : "+", Math.abs(off) / 60, Math.abs(off) % 60));
    }

    private void refreshAccess() {
        worker.execute(new Runnable() {
            @Override
            public void run() {
                final boolean wss = SyncEngine.hasSecureSettings(MainActivity.this);
                final boolean adb = AdbClient.isPortOpen(SyncEngine.ADB_HOST, SyncEngine.ADB_PORT, 1500);
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        access.setText(getString(R.string.access_line,
                                getString(wss ? R.string.yes : R.string.no),
                                getString(adb ? R.string.yes : R.string.no)));
                    }
                });
            }
        });
    }

    private void appendLog(final String text) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                log.append(text + "\n");
                scroll.post(new Runnable() {
                    @Override
                    public void run() {
                        scroll.fullScroll(View.FOCUS_DOWN);
                    }
                });
            }
        });
    }

    private void setStatus(final String text) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                status.setText(text);
            }
        });
    }

    private boolean begin() {
        if (busy) return false;
        busy = true;
        log.setText("");
        status.setText(R.string.status_working);
        return true;
    }

    private void runSync() {
        if (!begin()) return;
        worker.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    SyncEngine.Outcome o = SyncEngine.sync(MainActivity.this, engineLog, 60000);
                    switch (o.status) {
                        case SyncEngine.OK_ALREADY:
                            setStatus(getString(R.string.status_ok_already, o.offsetMs));
                            break;
                        case SyncEngine.OK_SET:
                            setStatus(getString(R.string.status_ok_set, o.remainingMs));
                            break;
                        case SyncEngine.PARTIAL:
                            setStatus(getString(R.string.status_partial, o.remainingMs / 1000));
                            break;
                        case SyncEngine.NO_ACCESS:
                            setStatus(getString(R.string.status_no_access, o.offsetMs / 1000));
                            appendLog("");
                            appendLog(getString(R.string.help_text));
                            break;
                        default:
                            setStatus(getString(R.string.status_no_source));
                    }
                } catch (Exception e) {
                    setStatus(String.valueOf(e));
                } finally {
                    busy = false;
                    refreshAccess();
                }
            }
        });
    }

    private void runTest() {
        if (!begin()) return;
        worker.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    String[][] groups = {Servers.NTP_IRAN, Servers.NTP_GLOBAL, Servers.HTTP_IRAN, Servers.HTTP_GLOBAL};
                    String[] names = {"IRAN - NTP", "GLOBAL - NTP", "IRAN - HTTP", "GLOBAL - HTTP"};
                    int okCount = 0, total = 0;
                    for (int i = 0; i < groups.length; i++) {
                        appendLog("== " + names[i] + " ==");
                        List<NtpClient.Result> rs = SyncEngine.queryAll(groups[i], i >= 2);
                        for (NtpClient.Result r : rs) {
                            appendLog(SyncEngine.describe(r));
                            total++;
                            if (r.ok) okCount++;
                        }
                    }
                    setStatus(okCount + " / " + total + " OK");
                } catch (Exception e) {
                    setStatus(String.valueOf(e));
                } finally {
                    busy = false;
                }
            }
        });
    }

    private void runZone() {
        if (!begin()) return;
        worker.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    boolean ok = SyncEngine.setTehranZone(MainActivity.this, engineLog);
                    setStatus(getString(ok ? R.string.zone_ok : R.string.zone_fail));
                } catch (Exception e) {
                    setStatus(String.valueOf(e));
                } finally {
                    busy = false;
                }
            }
        });
    }
}
