package com.tvtimesync.app;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/** Minimal SNTP client (RFC 4330). */
final class NtpClient {
    private NtpClient() {}

    private static final long EPOCH_OFFSET_SEC = 2208988800L;

    static final class Result {
        String source;
        boolean ok;
        String error;
        long offsetMs; // true time minus local clock
        long rttMs;
    }

    static Result query(String host, int timeoutMs) {
        Result r = new Result();
        r.source = host;
        DatagramSocket socket = null;
        try {
            InetAddress addr = InetAddress.getByName(host);
            socket = new DatagramSocket();
            socket.setSoTimeout(timeoutMs);
            byte[] buf = new byte[48];
            buf[0] = 0x23; // LI=0, VN=4, Mode=3 (client)
            long t1 = System.currentTimeMillis();
            long n1 = System.nanoTime();
            writeTimestamp(buf, 40, t1);
            socket.send(new DatagramPacket(buf, buf.length, addr, 123));
            DatagramPacket resp = new DatagramPacket(new byte[48], 48);
            socket.receive(resp);
            long elapsedMs = (System.nanoTime() - n1) / 1000000L;
            long t4 = t1 + elapsedMs;
            byte[] d = resp.getData();
            if (resp.getLength() < 48) throw new Exception("short reply");
            int li = (d[0] >> 6) & 3;
            int mode = d[0] & 7;
            int stratum = d[1] & 0xff;
            long t2 = readTimestamp(d, 32);
            long t3 = readTimestamp(d, 40);
            if (mode != 4 && mode != 5) throw new Exception("bad mode " + mode);
            if (li == 3) throw new Exception("server unsynchronized");
            if (stratum < 1 || stratum > 15) throw new Exception("bad stratum " + stratum);
            if (t3 == 0) throw new Exception("zero transmit time");
            r.offsetMs = ((t2 - t1) + (t3 - t4)) / 2;
            r.rttMs = Math.max(0, elapsedMs - (t3 - t2));
            r.ok = true;
        } catch (Exception e) {
            r.error = e.getClass().getSimpleName() + (e.getMessage() != null ? ": " + e.getMessage() : "");
        } finally {
            if (socket != null) socket.close();
        }
        return r;
    }

    private static long readTimestamp(byte[] b, int off) {
        long sec = 0, frac = 0;
        for (int i = 0; i < 4; i++) sec = (sec << 8) | (b[off + i] & 0xffL);
        for (int i = 4; i < 8; i++) frac = (frac << 8) | (b[off + i] & 0xffL);
        if (sec == 0 && frac == 0) return 0;
        // Era handling: seconds with the top bit clear belong to era 1 (after 2036).
        long unixSec = ((sec & 0x80000000L) != 0) ? sec - EPOCH_OFFSET_SEC : sec + 4294967296L - EPOCH_OFFSET_SEC;
        return unixSec * 1000L + (frac * 1000L) / 4294967296L;
    }

    private static void writeTimestamp(byte[] b, int off, long unixMs) {
        long sec = unixMs / 1000L + EPOCH_OFFSET_SEC;
        long frac = ((unixMs % 1000L) * 4294967296L) / 1000L;
        for (int i = 3; i >= 0; i--) { b[off + i] = (byte) sec; sec >>= 8; }
        for (int i = 7; i >= 4; i--) { b[off + i] = (byte) frac; frac >>= 8; }
    }
}
