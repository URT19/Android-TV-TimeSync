package com.tvtimesync.app;

/** Time source lists. Iranian sources are always tried first. */
final class Servers {
    private Servers() {}

    static final String[] NTP_IRAN = {
        "ntp.time.ir",
        "ntp.day.ir",
        "ir.pool.ntp.org",
        "0.ir.pool.ntp.org",
        "1.ir.pool.ntp.org",
        "2.ir.pool.ntp.org",
        "3.ir.pool.ntp.org",
        "ntp.iranet.ir",
        "time1.iran.ir",
        "ntp.snapp.ir",
        "ntp.parsonline.com",
        "ntp.ut.ac.ir",
        "public.ntp.asiatech.ir",
        "ntp.irimo.ir",
        "194.225.150.25",
        "2.188.16.51",
        "185.204.197.106",
    };

    static final String[] NTP_GLOBAL = {
        "time.google.com",
        "time1.google.com",
        "time2.google.com",
        "time3.google.com",
        "time4.google.com",
        "time.android.com",
        "time.cloudflare.com",
        "time.windows.com",
        "time.apple.com",
        "time.euro.apple.com",
        "time.asia.apple.com",
        "time.aws.com",
        "time.facebook.com",
        "time.nist.gov",
        "utcnist.colorado.edu",
        "tick.usno.navy.mil",
        "tock.usno.navy.mil",
        "pool.ntp.org",
        "0.pool.ntp.org",
        "1.pool.ntp.org",
        "2.pool.ntp.org",
        "3.pool.ntp.org",
        "asia.pool.ntp.org",
        "europe.pool.ntp.org",
        "north-america.pool.ntp.org",
        "south-america.pool.ntp.org",
        "africa.pool.ntp.org",
        "oceania.pool.ntp.org",
        "tr.pool.ntp.org",
        "ae.pool.ntp.org",
        "de.pool.ntp.org",
        "ru.pool.ntp.org",
        "ntp.ubuntu.com",
        "ntp.aliyun.com",
        "ntp.tencent.com",
        "ntp.ntsc.ac.cn",
        "ntp.nict.jp",
        "ptbtime1.ptb.de",
        "ptbtime2.ptb.de",
        "ntp.se",
        "ntp.time.nl",
        "ntp1.hetzner.de",
        "ntp.ripe.net",
    };

    /** Plain-HTTP fallback (Date header). HTTPS is avoided: it fails when the clock is wrong. */
    static final String[] HTTP_IRAN = {
        "http://time.ir/",
        "http://www.aparat.com/",
        "http://www.digikala.com/",
        "http://www.varzesh3.com/",
    };

    static final String[] HTTP_GLOBAL = {
        "http://www.google.com/",
        "http://www.cloudflare.com/",
        "http://www.microsoft.com/",
        "http://www.apple.com/",
    };
}
