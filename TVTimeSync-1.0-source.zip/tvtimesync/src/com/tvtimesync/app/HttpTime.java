package com.tvtimesync.app;

import java.net.HttpURLConnection;
import java.net.URL;

/** Fallback time source: the Date header of a plain HTTP response (1 second resolution). */
final class HttpTime {
    private HttpTime() {}

    static NtpClient.Result query(String url, int timeoutMs) {
        NtpClient.Result r = new NtpClient.Result();
        r.source = url;
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setRequestMethod("HEAD");
            c.setConnectTimeout(timeoutMs);
            c.setReadTimeout(timeoutMs);
            c.setUseCaches(false);
            long t1 = System.currentTimeMillis();
            long n1 = System.nanoTime();
            c.getResponseCode();
            long elapsedMs = (System.nanoTime() - n1) / 1000000L;
            long date = c.getHeaderFieldDate("Date", 0);
            if (date <= 0) throw new Exception("no Date header");
            // Header has whole seconds; assume the middle of the second.
            r.offsetMs = (date + 500) - (t1 + elapsedMs / 2);
            r.rttMs = elapsedMs;
            r.ok = true;
        } catch (Exception e) {
            r.error = e.getClass().getSimpleName() + (e.getMessage() != null ? ": " + e.getMessage() : "");
        } finally {
            if (c != null) c.disconnect();
        }
        return r;
    }
}
