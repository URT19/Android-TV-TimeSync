package com.tvtimesync.app;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Minimal ADB client (plain TCP transport, RSA auth, one-shot shell commands). */
final class AdbClient implements Closeable {
    private static final int A_CNXN = 0x4e584e43;
    private static final int A_AUTH = 0x48545541;
    private static final int A_OPEN = 0x4e45504f;
    private static final int A_OKAY = 0x59414b4f;
    private static final int A_CLSE = 0x45534c43;
    private static final int A_WRTE = 0x45545257;
    private static final int A_STLS = 0x534c5453;

    private static final int AUTH_TOKEN = 1;
    private static final int AUTH_SIGNATURE = 2;
    private static final int AUTH_RSAPUBLICKEY = 3;

    private static final int VERSION = 0x01000000;
    private static final int MAX_DATA = 4096;

    interface ApprovalListener {
        void onWaitingForApproval();
    }

    private static final class Msg {
        int cmd, arg0, arg1;
        byte[] data;
    }

    private Socket socket;
    private InputStream in;
    private OutputStream out;
    private int nextLocalId = 1;

    static boolean isPortOpen(String host, int port, int timeoutMs) {
        Socket s = new Socket();
        try {
            s.connect(new InetSocketAddress(host, port), timeoutMs);
            return true;
        } catch (IOException e) {
            return false;
        } finally {
            try { s.close(); } catch (IOException ignored) { }
        }
    }

    void connect(String host, int port, AdbCrypto crypto, int approvalTimeoutMs,
                 ApprovalListener listener) throws Exception {
        socket = new Socket();
        socket.connect(new InetSocketAddress(host, port), 3000);
        socket.setTcpNoDelay(true);
        socket.setSoTimeout(10000);
        in = socket.getInputStream();
        out = socket.getOutputStream();

        send(A_CNXN, VERSION, MAX_DATA, "host::\0".getBytes());
        boolean sentSignature = false;
        boolean sentKey = false;
        while (true) {
            Msg m = read();
            if (m.cmd == A_CNXN) {
                socket.setSoTimeout(15000);
                return;
            } else if (m.cmd == A_AUTH && m.arg0 == AUTH_TOKEN) {
                if (!sentSignature) {
                    sentSignature = true;
                    send(A_AUTH, AUTH_SIGNATURE, 0, crypto.sign(m.data));
                } else if (!sentKey) {
                    sentKey = true;
                    send(A_AUTH, AUTH_RSAPUBLICKEY, 0, crypto.adbPublicKey());
                    socket.setSoTimeout(approvalTimeoutMs);
                    if (listener != null) listener.onWaitingForApproval();
                } else {
                    throw new IOException("ADB authorization rejected");
                }
            } else if (m.cmd == A_STLS) {
                throw new IOException("device requires TLS (wireless debugging) - not supported");
            } else {
                throw new IOException("unexpected ADB message during connect");
            }
        }
    }

    /** Runs a shell command and returns its combined output. */
    String shell(String command) throws Exception {
        int localId = nextLocalId++;
        send(A_OPEN, localId, 0, ("shell:" + command + "\0").getBytes());
        ByteArrayOutputStream result = new ByteArrayOutputStream();
        int remoteId = 0;
        while (true) {
            Msg m = read();
            if (m.arg1 != localId && m.arg1 != 0) continue; // stale stream
            if (m.cmd == A_OKAY) {
                remoteId = m.arg0;
            } else if (m.cmd == A_WRTE) {
                remoteId = m.arg0;
                result.write(m.data, 0, m.data.length);
                send(A_OKAY, localId, remoteId, new byte[0]);
            } else if (m.cmd == A_CLSE) {
                if (m.arg0 != 0) send(A_CLSE, localId, m.arg0, new byte[0]);
                return result.toString("UTF-8");
            }
        }
    }

    /** Runs a command and returns true when its exit status is 0. Output is appended to sb. */
    boolean run(String command, StringBuilder sb) throws Exception {
        String o = shell(command + " 2>&1; echo __RC=$?");
        if (sb != null) sb.append(o.trim());
        return o.contains("__RC=0");
    }

    private void send(int cmd, int arg0, int arg1, byte[] data) throws IOException {
        int sum = 0;
        for (byte b : data) sum += (b & 0xff);
        ByteBuffer bb = ByteBuffer.allocate(24 + data.length).order(ByteOrder.LITTLE_ENDIAN);
        bb.putInt(cmd).putInt(arg0).putInt(arg1).putInt(data.length).putInt(sum).putInt(~cmd);
        bb.put(data);
        out.write(bb.array());
        out.flush();
    }

    private Msg read() throws IOException {
        byte[] h = readFully(24);
        ByteBuffer bb = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN);
        Msg m = new Msg();
        m.cmd = bb.getInt();
        m.arg0 = bb.getInt();
        m.arg1 = bb.getInt();
        int len = bb.getInt();
        bb.getInt(); // checksum (ignored)
        int magic = bb.getInt();
        if (magic != ~m.cmd) throw new IOException("bad ADB magic");
        if (len < 0 || len > (1 << 20)) throw new IOException("bad ADB length");
        m.data = readFully(len);
        return m;
    }

    private byte[] readFully(int n) throws IOException {
        byte[] b = new byte[n];
        int off = 0;
        while (off < n) {
            int r = in.read(b, off, n - off);
            if (r < 0) throw new IOException("ADB connection closed");
            off += r;
        }
        return b;
    }

    @Override
    public void close() {
        try {
            if (socket != null) socket.close();
        } catch (IOException ignored) {
        }
    }
}
