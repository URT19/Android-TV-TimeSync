package com.tvtimesync.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.widget.Toast;

/** Silent background sync, started after boot. */
public class SyncService extends Service {
    private static final String CHANNEL = "sync";
    private static final int MAX_ATTEMPTS = 12;
    private static final long RETRY_DELAY_MS = 10000;
    private volatile boolean running;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(1, buildNotification());
        if (!running) {
            running = true;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    work();
                }
            }, "boot-sync").start();
        }
        return START_NOT_STICKY;
    }

    private Notification buildNotification() {
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, getString(R.string.app_name),
                    NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        return b.setSmallIcon(android.R.drawable.ic_popup_sync)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.notif_text))
                .build();
    }

    private void work() {
        SyncEngine.Log quiet = new SyncEngine.Log() {
            @Override
            public void line(String text) {
                android.util.Log.i("TvTimeSync", text);
            }

            @Override
            public void waitingForApproval() {
            }
        };
        boolean ok = false;
        boolean changed = false;
        try {
            for (int i = 0; i < MAX_ATTEMPTS; i++) {
                SyncEngine.Outcome o = SyncEngine.sync(this, quiet, 30000);
                if (o.status == SyncEngine.OK_ALREADY || o.status == SyncEngine.OK_SET) {
                    ok = true;
                    changed = o.status == SyncEngine.OK_SET;
                    break;
                }
                Thread.sleep(RETRY_DELAY_MS);
            }
        } catch (Exception e) {
            android.util.Log.w("TvTimeSync", "boot sync failed", e);
        }
        final int msg = ok ? R.string.toast_ok : R.string.toast_fail;
        if (changed || !ok) {
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
                }
            });
        }
        running = false;
        if (Build.VERSION.SDK_INT >= 24) {
            stopForeground(STOP_FOREGROUND_REMOVE);
        } else {
            stopForeground(true);
        }
        stopSelf();
    }
}
