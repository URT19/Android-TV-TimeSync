package com.tvtimesync.app;

import android.content.Context;

final class Prefs {
    private Prefs() {}

    private static final String FILE = "prefs";
    private static final String KEY_BOOT = "run_at_boot";

    static boolean runAtBoot(Context c) {
        return c.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(KEY_BOOT, false);
    }

    static void setRunAtBoot(Context c, boolean on) {
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(KEY_BOOT, on).apply();
    }
}
