package com.tvtimesync.app;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.Cipher;

/** RSA key handling for ADB authentication. */
final class AdbCrypto {
    private static final int KEY_BITS = 2048;
    private static final int KEY_WORDS = KEY_BITS / 32;

    /** ASN.1 DigestInfo prefix for SHA-1; the ADB token is signed as if it were a SHA-1 digest. */
    private static final byte[] SHA1_PREFIX = {
        0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e, 0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14
    };

    private final PrivateKey privateKey;
    private final RSAPublicKey publicKey;

    private AdbCrypto(PrivateKey priv, RSAPublicKey pub) {
        this.privateKey = priv;
        this.publicKey = pub;
    }

    static AdbCrypto loadOrCreate(File dir) throws Exception {
        File privFile = new File(dir, "adbkey.pk8");
        File pubFile = new File(dir, "adbkey.x509");
        if (privFile.exists() && pubFile.exists()) {
            try {
                KeyFactory kf = KeyFactory.getInstance("RSA");
                PrivateKey priv = kf.generatePrivate(new PKCS8EncodedKeySpec(readAll(privFile)));
                RSAPublicKey pub = (RSAPublicKey) kf.generatePublic(new X509EncodedKeySpec(readAll(pubFile)));
                return new AdbCrypto(priv, pub);
            } catch (Exception ignored) {
                // fall through and regenerate
            }
        }
        KeyPairGenerator gen = KeyPairGenerator.getInstance("RSA");
        gen.initialize(KEY_BITS);
        KeyPair kp = gen.generateKeyPair();
        writeAll(privFile, kp.getPrivate().getEncoded());
        writeAll(pubFile, kp.getPublic().getEncoded());
        return new AdbCrypto(kp.getPrivate(), (RSAPublicKey) kp.getPublic());
    }

    byte[] sign(byte[] token) throws Exception {
        Cipher c = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        c.init(Cipher.ENCRYPT_MODE, privateKey);
        c.update(SHA1_PREFIX);
        return c.doFinal(token);
    }

    /** Public key in the ADB wire format: base64(struct) + " name" + NUL. */
    byte[] adbPublicKey() {
        BigInteger n = publicKey.getModulus();
        BigInteger r32 = BigInteger.ZERO.setBit(32);
        BigInteger r = BigInteger.ZERO.setBit(KEY_BITS);
        BigInteger rr = r.multiply(r).mod(n);
        int n0inv = n.mod(r32).modInverse(r32).negate().intValue();

        ByteBuffer bb = ByteBuffer.allocate(4 + 4 + KEY_WORDS * 4 * 2 + 4).order(ByteOrder.LITTLE_ENDIAN);
        bb.putInt(KEY_WORDS);
        bb.putInt(n0inv);
        putLittleEndian(bb, n);
        putLittleEndian(bb, rr);
        bb.putInt(publicKey.getPublicExponent().intValue());

        byte[] text = (base64(bb.array()) + " tvtimesync@tv").getBytes();
        byte[] out = new byte[text.length + 1];
        System.arraycopy(text, 0, out, 0, text.length);
        return out;
    }

    private static void putLittleEndian(ByteBuffer bb, BigInteger v) {
        BigInteger mask = BigInteger.ZERO.setBit(32).subtract(BigInteger.ONE);
        for (int i = 0; i < KEY_WORDS; i++) {
            bb.putInt(v.and(mask).intValue());
            v = v.shiftRight(32);
        }
    }

    private static final char[] B64 =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".toCharArray();

    static String base64(byte[] d) {
        StringBuilder sb = new StringBuilder((d.length + 2) / 3 * 4);
        for (int i = 0; i < d.length; i += 3) {
            int b0 = d[i] & 0xff;
            int b1 = i + 1 < d.length ? d[i + 1] & 0xff : 0;
            int b2 = i + 2 < d.length ? d[i + 2] & 0xff : 0;
            sb.append(B64[b0 >> 2]);
            sb.append(B64[((b0 & 3) << 4) | (b1 >> 4)]);
            sb.append(i + 1 < d.length ? B64[((b1 & 15) << 2) | (b2 >> 6)] : '=');
            sb.append(i + 2 < d.length ? B64[b2 & 63] : '=');
        }
        return sb.toString();
    }

    private static byte[] readAll(File f) throws Exception {
        byte[] b = new byte[(int) f.length()];
        FileInputStream in = new FileInputStream(f);
        try {
            int off = 0;
            while (off < b.length) {
                int n = in.read(b, off, b.length - off);
                if (n < 0) throw new Exception("truncated key file");
                off += n;
            }
        } finally {
            in.close();
        }
        return b;
    }

    private static void writeAll(File f, byte[] b) throws Exception {
        FileOutputStream out = new FileOutputStream(f);
        try {
            out.write(b);
        } finally {
            out.close();
        }
    }
}
