package com.tvtimesync.app;

import android.app.AlarmManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.provider.Settings;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/** Measures the clock error against time servers and corrects the system clock. */
final class SyncEngine {
    private SyncEngine() {}

    static final int OK_ALREADY = 0;
    static final int OK_SET = 1;
    static final int PARTIAL = 2;
    static final int NO_SOURCE = 3;
    static final int NO_ACCESS = 4;

    static final String ADB_HOST = "127.0.0.1";
    static final int ADB_PORT = 5555;
    private static final long TOLERANCE_MS = 1500;
    private static final int NTP_TIMEOUT_MS = 3000;
    private static final int HTTP_TIMEOUT_MS = 5000;
    private static final String WSS = "android.permission.WRITE_SECURE_SETTINGS";

    interface Log {
        void line(String text);
        void waitingForApproval();
    }

    static final class Outcome {
        int status;
        long offsetMs;
        long remainingMs;
        String source;
    }

    static boolean hasSecureSettings(Context ctx) {
        return ctx.checkCallingOrSelfPermission(WSS) == PackageManager.PERMISSION_GRANTED;
    }

    /** Queries a group of sources in parallel. */
    static List<NtpClient.Result> queryAll(final String[] sources, final boolean http) {
        ExecutorService pool = Executors.newFixedThreadPool(Math.min(12, sources.length));
        List<Future<NtpClient.Result>> futures = new ArrayList<Future<NtpClient.Result>>();
        for (final String s : sources) {
            futures.add(pool.submit(new Callable<NtpClient.Result>() {
                @Override
                public NtpClient.Result call() {
                    return http ? HttpTime.query(s, HTTP_TIMEOUT_MS) : NtpClient.query(s, NTP_TIMEOUT_MS);
                }
            }));
        }
        List<NtpClient.Result> out = new ArrayList<NtpClient.Result>();
        for (int i = 0; i < futures.size(); i++) {
            try {
                out.add(futures.get(i).get(30, TimeUnit.SECONDS));
            } catch (Exception e) {
                NtpClient.Result r = new NtpClient.Result();
                r.source = sources[i];
                r.error = "timeout";
                out.add(r);
            }
        }
        pool.shutdownNow();
        return out;
    }

    /** Picks the lowest-latency answer that agrees with the median of all answers. */
    static NtpClient.Result pick(List<NtpClient.Result> results) {
        List<Long> offsets = new ArrayList<Long>();
        for (NtpClient.Result r : results) if (r.ok) offsets.add(r.offsetMs);
        if (offsets.isEmpty()) return null;
        Collections.sort(offsets);
        long median = offsets.get(offsets.size() / 2);
        NtpClient.Result best = null;
        for (NtpClient.Result r : results) {
            if (!r.ok || Math.abs(r.offsetMs - median) > 3000) continue;
            if (best == null || r.rttMs < best.rttMs) best = r;
        }
        return best;
    }

    static String describe(NtpClient.Result r) {
        if (r.ok) {
            return String.format(Locale.US, "  OK    %-28s rtt %4d ms   offset %d ms", r.source, r.rttMs, r.offsetMs);
        }
        return String.format(Locale.US, "  FAIL  %-28s %s", r.source, r.error);
    }

    private static NtpClient.Result measure(Log log) {
        String[][] groups = {Servers.NTP_IRAN, Servers.NTP_GLOBAL, Servers.HTTP_IRAN, Servers.HTTP_GLOBAL};
        String[] names = {"Iran NTP", "Global NTP", "Iran HTTP", "Global HTTP"};
        for (int i = 0; i < groups.length; i++) {
            log.line("Querying " + names[i] + " servers...");
            NtpClient.Result best = pick(queryAll(groups[i], i >= 2));
            if (best != null) {
                log.line("Using " + best.source + " (rtt " + best.rttMs + " ms)");
                return best;
            }
            log.line("No answer from " + names[i] + ".");
        }
        return null;
    }

    private static NtpClient.Result remeasure(NtpClient.Result first) {
        boolean http = first.source.startsWith("http");
        for (int i = 0; i < 2; i++) {
            NtpClient.Result r = http ? HttpTime.query(first.source, HTTP_TIMEOUT_MS)
                    : NtpClient.query(first.source, NTP_TIMEOUT_MS);
            if (r.ok) return r;
        }
        return null;
    }

    private static AdbClient openAdb(Context ctx, final Log log, int approvalTimeoutMs) {
        if (!AdbClient.isPortOpen(ADB_HOST, ADB_PORT, 1500)) {
            log.line("Local ADB port " + ADB_PORT + " is closed.");
            return null;
        }
        AdbClient adb = new AdbClient();
        try {
            AdbCrypto crypto = AdbCrypto.loadOrCreate(ctx.getFilesDir());
            adb.connect(ADB_HOST, ADB_PORT, crypto, approvalTimeoutMs, new AdbClient.ApprovalListener() {
                @Override
                public void onWaitingForApproval() {
                    log.waitingForApproval();
                }
            });
            log.line("Local ADB connected.");
            return adb;
        } catch (Exception e) {
            log.line("Local ADB failed: " + e.getMessage());
            adb.close();
            return null;
        }
    }

    private static void toggleAutoTime(ContentResolver cr) {
        Settings.Global.putInt(cr, Settings.Global.AUTO_TIME, 0);
        sleep(500);
        Settings.Global.putInt(cr, Settings.Global.AUTO_TIME, 1);
    }

    static Outcome sync(Context ctx, Log log, int approvalTimeoutMs) {
        Outcome o = new Outcome();
        NtpClient.Result best = measure(log);
        if (best == null) {
            o.status = NO_SOURCE;
            return o;
        }
        o.source = best.source;
        o.offsetMs = best.offsetMs;
        o.remainingMs = best.offsetMs;
        log.line("Clock error: " + best.offsetMs + " ms");
        boolean isNtp = !best.source.startsWith("http");
        String ntpHost = isNtp ? best.source : Servers.NTP_IRAN[0];

        if (Math.abs(best.offsetMs) <= TOLERANCE_MS) {
            if (hasSecureSettings(ctx)) {
                try {
                    Settings.Global.putString(ctx.getContentResolver(), "ntp_server", ntpHost);
                } catch (Exception ignored) {
                }
            }
            o.status = OK_ALREADY;
            return o;
        }

        boolean applied = false;
        boolean direct = false;
        AdbClient adb = openAdb(ctx, log, approvalTimeoutMs);
        if (adb != null) {
            try {
                StringBuilder sb = new StringBuilder();
                adb.run("pm grant " + ctx.getPackageName() + " " + WSS, null);
                adb.run("settings put global ntp_server " + ntpHost, null);
                log.line("System time server set to " + ntpHost);
                applied = true;
                long target = System.currentTimeMillis() + best.offsetMs;
                direct = adb.run("cmd alarm set-time " + target, sb);
                log.line(direct ? "Clock set directly through ADB." : "Direct set not available: " + sb);
                if (!direct) {
                    adb.run("settings put global auto_time 0", null);
                    sleep(500);
                    adb.run("settings put global auto_time 1", null);
                    log.line("Asked the system to resync from " + ntpHost);
                }
            } catch (Exception e) {
                log.line("ADB command failed: " + e.getMessage());
            } finally {
                adb.close();
            }
        }
        if (!direct && hasSecureSettings(ctx)) {
            try {
                ContentResolver cr = ctx.getContentResolver();
                Settings.Global.putString(cr, "ntp_server", ntpHost);
                toggleAutoTime(cr);
                applied = true;
                log.line("Time server set to " + ntpHost + "; system resync requested.");
            } catch (Exception e) {
                log.line("Settings write failed: " + e.getMessage());
            }
        }
        if (!applied) {
            o.status = NO_ACCESS;
            return o;
        }

        // Verify. The system resync path is asynchronous, so give it some time.
        int rounds = direct ? 2 : 6;
        for (int i = 0; i < rounds; i++) {
            sleep(direct ? 300 : 3000);
            NtpClient.Result again = remeasure(best);
            if (again == null) continue;
            o.remainingMs = again.offsetMs;
            if (Math.abs(again.offsetMs) <= TOLERANCE_MS) {
                o.status = OK_SET;
                return o;
            }
        }
        o.status = PARTIAL;
        return o;
    }

    static boolean setTehranZone(Context ctx, Log log) {
        final String zone = "Asia/Tehran";
        AdbClient adb = openAdb(ctx, log, 60000);
        if (adb != null) {
            try {
                StringBuilder sb = new StringBuilder();
                if (adb.run("cmd alarm set-timezone " + zone, sb)) return true;
                log.line("ADB set-timezone failed: " + sb);
            } catch (Exception e) {
                log.line("ADB command failed: " + e.getMessage());
            } finally {
                adb.close();
            }
        }
        try {
            ((AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE)).setTimeZone(zone);
            sleep(500);
            return zone.equals(java.util.TimeZone.getDefault().getID());
        } catch (Exception e) {
            log.line("setTimeZone failed: " + e.getMessage());
            return false;
        }
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
        }
    }
}
