import socket, struct, time, sys
SHIFT = float(sys.argv[1])
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.bind(('127.0.0.1', 123))
while True:
    d, a = s.recvfrom(64)
    now = time.time() + SHIFT + 2208988800
    ts = struct.pack('>II', int(now), int((now % 1) * 2**32))
    s.sendto(bytes([0x24, 2, 0, 0]) + b'\0' * 20 + d[40:48] + ts + ts, a)
