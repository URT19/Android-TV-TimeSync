package com.tvtimesync.app;
import java.io.File;
public class T {
    public static void main(String[] a) throws Exception {
        int[] j = Jalali.fromGregorian(2026, 11, 14);
        System.out.println("jalali 2026-11-14 = " + j[0] + "/" + j[1] + "/" + j[2]);
        j = Jalali.fromGregorian(2026, 3, 21);
        System.out.println("jalali 2026-03-21 = " + j[0] + "/" + j[1] + "/" + j[2]);
        j = Jalali.fromGregorian(2025, 3, 20);
        System.out.println("jalali 2025-03-20 = " + j[0] + "/" + j[1] + "/" + j[2]);
        NtpClient.Result r = NtpClient.query("127.0.0.1", 2000);
        System.out.println("ntp ok=" + r.ok + " offset=" + r.offsetMs + " rtt=" + r.rttMs + " err=" + r.error);
        File dir = new File(a[0]); dir.mkdirs();
        for (int i = 0; i < 2; i++) {
            AdbClient c = new AdbClient();
            c.connect("127.0.0.1", 5555, AdbCrypto.loadOrCreate(dir), 5000, null);
            StringBuilder sb = new StringBuilder();
            System.out.println("run ok=" + c.run("cmd alarm set-time 123", sb) + " out=[" + sb + "]");
            System.out.println("run fail=" + c.run("failme", null));
            c.close();
        }
    }
}
