import socket, struct, os, base64, sys, threading
from cryptography.hazmat.primitives.asymmetric import rsa, padding, utils
from cryptography.hazmat.primitives import hashes

def cmd(s): return struct.unpack('<I', s)[0]
CNXN, AUTH, OPEN, OKAY, CLSE, WRTE = [cmd(x) for x in (b'CNXN', b'AUTH', b'OPEN', b'OKAY', b'CLSE', b'WRTE')]

def send(c, command, a0, a1, data=b''):
    c.sendall(struct.pack('<6I', command, a0, a1, len(data), sum(data) & 0xffffffff, command ^ 0xffffffff) + data)

def recvn(c, n):
    b = b''
    while len(b) < n:
        d = c.recv(n - len(b))
        if not d: raise EOFError
        b += d
    return b

def recv(c):
    command, a0, a1, ln, csum, magic = struct.unpack('<6I', recvn(c, 24))
    assert magic == command ^ 0xffffffff, 'magic'
    data = recvn(c, ln)
    assert csum == sum(data) & 0xffffffff, 'checksum'
    return command, a0, a1, data

known = []
def verify(pub, token, sig):
    try:
        pub.verify(sig, token, padding.PKCS1v15(), utils.Prehashed(hashes.SHA1()))
        return True
    except Exception:
        return False

def parse_key(data):
    assert data.endswith(b'\0')
    b64 = data[:-1].split(b' ')[0]
    raw = base64.b64decode(b64)
    assert len(raw) == 524, len(raw)
    words, n0inv = struct.unpack('<II', raw[:8])
    assert words == 64
    n = int.from_bytes(raw[8:264], 'little')
    rr = int.from_bytes(raw[264:520], 'little')
    e = struct.unpack('<I', raw[520:])[0]
    assert e == 65537
    assert rr == pow(2, 4096, n), 'rr'
    assert (n * n0inv + 1) % (1 << 32) == 0, 'n0inv'
    return rsa.RSAPublicNumbers(e, n).public_key()

def handle(c):
    command, a0, a1, data = recv(c)
    assert command == CNXN and data == b'host::\0'
    token = os.urandom(20)
    send(c, AUTH, 1, 0, token)
    command, a0, a1, sig = recv(c)
    assert command == AUTH and a0 == 2
    if not any(verify(k, token, sig) for k in known):
        token2 = os.urandom(20)
        send(c, AUTH, 1, 0, token2)
        command, a0, a1, key = recv(c)
        assert command == AUTH and a0 == 3
        pub = parse_key(key)
        assert verify(pub, token, sig), 'signature does not verify'
        known.append(pub)
        print('SERVER: new key accepted, signature valid', flush=True)
    else:
        print('SERVER: known key, signature valid', flush=True)
    send(c, CNXN, 0x01000001, 256 * 1024, b'device::ro.product.name=fake\0')
    rid = 100
    while True:
        try: command, a0, a1, data = recv(c)
        except EOFError: return
        if command == OPEN:
            rid += 1
            line = data.rstrip(b'\0').decode()
            print('SERVER: ' + line, flush=True)
            send(c, OKAY, rid, a0)
            rc = 1 if 'failme' in line else 0
            out = ('some output\n__RC=%d\n' % rc).encode()
            send(c, WRTE, rid, a0, out[:5]); assert recv(c)[0] == OKAY
            send(c, WRTE, rid, a0, out[5:]); assert recv(c)[0] == OKAY
            send(c, CLSE, rid, a0)

s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(('127.0.0.1', 5555)); s.listen(5)
while True:
    c, _ = s.accept()
    threading.Thread(target=handle, args=(c,), daemon=True).start()
