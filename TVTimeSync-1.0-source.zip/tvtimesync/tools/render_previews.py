"""Renders UI preview images from the app layout (sample data, not device captures)."""
from PIL import Image, ImageDraw, ImageFont

S = 2  # px per dp at 1080p
W, H = 1920, 1080
D = "/usr/share/fonts/truetype/dejavu/"
def font(name, sp): return ImageFont.truetype(D + name, int(sp * S))
REG, BOLD, THIN = "DejaVuSans.ttf", "DejaVuSans-Bold.ttf", "DejaVuSans-ExtraLight.ttf"
TEXT, DIM, ACCENT, CARD, STROKE = (242, 245, 255), (154, 166, 204), (79, 140, 255), (26, 34, 64), (51, 69, 111)

def background():
    im = Image.new("RGB", (W, H))
    px = im.load()
    for y in range(H):
        for x in range(W):
            t = (x / W + y / H) / 2
            px[x, y] = (int(11 + t * 11), int(16 + t * 16), int(32 + t * 42))
    return im

def render(path, status, access, log_lines, focused, boot_on):
    im = background()
    d = ImageDraw.Draw(im)
    pad = 40 * S
    left_w = int((W - 2 * pad) * 1.1 / 2.1)
    x, y = pad, pad
    d.text((x, y), "TV Time Sync", font=font(BOLD, 20), fill=ACCENT); y += 30 * S
    d.text((x - 6, y), "21:47:05", font=font(THIN, 92), fill=TEXT); y += 116 * S
    d.text((x, y), "Saturday, 14 November 2026", font=font(REG, 24), fill=TEXT); y += 36 * S
    d.text((x, y), "23 Aban 1405   (1405/08/23)", font=font(REG, 24), fill=TEXT); y += 36 * S
    d.text((x, y), "Asia/Tehran  (UTC+03:30)", font=font(REG, 16), fill=DIM); y += 24 * S + 20 * S
    card_r = x + left_w - 32 * S
    d.rounded_rectangle([x, y, card_r, y + 96 * S], radius=16 * S, fill=CARD)
    d.text((x + 18 * S, y + 18 * S), status, font=font(REG, 18), fill=TEXT)
    d.text((x + 18 * S, y + 54 * S), access, font=font(REG, 12.5), fill=DIM)

    rx = pad + left_w
    rr = W - pad
    y = pad
    labels = ["Sync now", "Auto-run at boot: " + ("ON" if boot_on else "OFF"), "Test all servers",
              "Set time zone to Tehran", "Setup guide"]
    for i, label in enumerate(labels):
        box = [rx, y, rr, y + 52 * S]
        if i == focused:
            d.rounded_rectangle(box, radius=14 * S, fill=ACCENT)
        else:
            d.rounded_rectangle(box, radius=14 * S, fill=CARD, outline=STROKE, width=S)
        f = font(REG, 17)
        tw = d.textlength(label, font=f)
        d.text(((rx + rr - tw) / 2, y + 15 * S), label, font=f, fill=TEXT)
        y += 62 * S
    d.rounded_rectangle([rx, y, rr, H - pad], radius=16 * S, fill=CARD)
    ly = y + 14 * S
    f = font("DejaVuSansMono.ttf", 11.5)
    for line in log_lines:
        if ly > H - pad - 30 * S: break
        d.text((rx + 14 * S, ly), line, font=f, fill=DIM); ly += 17 * S
    im.save(path, optimize=True)

ACCESS = "Secure-settings permission: yes   |   Local ADB (port 5555): yes"
render("screenshots/main.png", "Clock updated. Remaining offset: 12 ms", ACCESS, [
    "Querying Iran NTP servers...",
    "Using ntp.time.ir (rtt 18 ms)",
    "Clock error: 3541207 ms",
    "Local ADB connected.",
    "System time server set to ntp.time.ir",
    "Clock set directly through ADB.",
], focused=0, boot_on=True)
render("screenshots/server-test.png", "38 / 68 OK", ACCESS, [
    "== IRAN - NTP ==",
    "  OK    ntp.time.ir          rtt  18 ms  offset 9 ms",
    "  OK    ntp.day.ir           rtt  24 ms  offset 11 ms",
    "  OK    ir.pool.ntp.org      rtt  21 ms  offset 7 ms",
    "  FAIL  ntp.iranet.ir        SocketTimeoutException",
    "  OK    time1.iran.ir        rtt  33 ms  offset 14 ms",
    "== GLOBAL - NTP ==",
    "  OK    time.cloudflare.com  rtt  96 ms  offset 10 ms",
    "  FAIL  time.google.com      SocketTimeoutException",
    "  OK    pool.ntp.org         rtt 112 ms  offset 8 ms",
], focused=2, boot_on=True)
render("screenshots/setup-guide.png", "Ready", "Secure-settings permission: no   |   Local ADB (port 5555): no", [
    "ONE-TIME SETUP (TV is not rooted)",
    "",
    "1) Settings > Device Preferences > About >",
    "   press \"Build\" 7 times.",
    "2) Settings > Device Preferences > Developer",
    "   options > turn ON \"USB debugging\"",
    "   (and \"Network/ADB debugging\" if present).",
    "3) Come back here and press \"Sync now\". When",
    "   the TV asks \"Allow USB debugging?\", tick",
    "   \"Always allow\" and press OK.",
], focused=4, boot_on=False)
